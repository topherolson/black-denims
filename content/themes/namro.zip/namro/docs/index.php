<?php 
header('location: http://messaworks.com/themes/namro/docs/gh/index.html'); 
exit; 
?>